/**
 * TOC Component - Replaced with ChatSidebar
 */

import React from 'react';
import ChatSidebar from '../ChatSidebar';

export default function TOC() {
  return (
    <div style={{
      position: 'sticky',
      top: 0,
      height: '100vh',
      overflow: 'hidden',
    }}>
      <ChatSidebar />
    </div>
  );
}
