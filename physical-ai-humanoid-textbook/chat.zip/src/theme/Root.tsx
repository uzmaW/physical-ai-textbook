import React from 'react';

// Root wrapper - no modifications needed
// Chatbox is added via TOC component swizzle
export default function Root({children}) {
  return <>{children}</>;
}
