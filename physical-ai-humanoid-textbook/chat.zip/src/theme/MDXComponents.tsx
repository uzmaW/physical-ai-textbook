import React from 'react';
import MDXComponents from '@theme-original/MDXComponents';
import { PersonalizedChapter } from '@site/src/components/PersonalizedChapter';
import Tabs from '@theme/Tabs';
import TabItem from '@theme/TabItem';

export default {
  ...MDXComponents,
  PersonalizedChapter,
  Tabs,
  TabItem,
};
