/**
 * RAG Chat Widget for right sidebar
 * Enhanced with selected-text support and backend integration
 * Modern design matching docusaurus-integration theme
 */

import React, { useState, useEffect, useRef } from 'react';
import { useUserStore } from '@site/src/store/userStore';
import { sendChatMessage, type Citation } from '@site/src/services/apiService';
import { AuthButton } from './AuthButton';
import styles from './ChatUI.module.css';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  citations?: Citation[];
}

export function RAGChatWidget() {
  const { userProfile } = useUserStore();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hello! I'm your AI Tutor. Ask me anything about the textbook content!",
    },
  ]);
  const [input, setInput] = useState('');
  const [selectedText, setSelectedText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isTranslating, setIsTranslating] = useState(false);
  const [translateToUrdu, setTranslateToUrdu] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Detect text selection
  useEffect(() => {
    const handleSelection = () => {
      const selection = window.getSelection();
      const text = selection?.toString().trim() || '';
      if (text && text.length > 10 && text.length < 500) {
        setSelectedText(text);
      }
    };

    document.addEventListener('mouseup', handleSelection);
    return () => document.removeEventListener('mouseup', handleSelection);
  }, []);

  const sendMessage = async (messageText?: string, context?: string) => {
    const textToSend = messageText || input;
    if (!textToSend.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: textToSend,
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // Use the API service for proper backend communication
      const data = await sendChatMessage({
        message: textToSend,
        selectedText: context || selectedText,
        userLevel: userProfile?.preferences?.difficulty_preference || 'intermediate',
        language: userProfile?.preferences?.language || 'en',
      });

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.answer,
        citations: data.citations,
      };

      setMessages(prev => [...prev, assistantMessage]);
      setSelectedText(''); // Clear selection after use
    } catch (error) {
      console.error('Chat error:', error);

      // Error message (apiService already provides a user-friendly fallback)
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: error instanceof Error ? error.message : '❌ An unexpected error occurred. Please try again.',
      };

      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={`${styles.chatContainer} ${isExpanded ? styles.chatContainerExpanded : styles.chatContainerCollapsed}`}>
      {/* Header */}
      <div className={styles.chatHeader}>
        <div className={styles.headerTitle}>
          <span className={styles.headerIcon}>🤖</span>
          <span>AI Tutor</span>
        </div>
        <div className={styles.headerSubtitle}>
          Ask me anything about the textbook
        </div>
        <div className={styles.headerActions}>
          <button
            className={styles.expandButton}
            onClick={() => setIsExpanded(!isExpanded)}
            title={isExpanded ? 'Collapse' : 'Expand'}
          >
            {isExpanded ? '← Collapse' : 'Expand →'}
          </button>
          <AuthButton />
        </div>
      </div>

      {/* Messages */}
      <div className={styles.messagesContainer}>
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`${styles.message} ${msg.role === 'user' ? styles.messageUser : styles.messageAssistant}`}
          >
            <div className={styles.messageBubble}>
              {msg.content}

              {/* Citations */}
              {msg.citations && msg.citations.length > 0 && (
                <div className={styles.citations}>
                  <div className={styles.citationsLabel}>
                    📚 Sources:
                  </div>
                  <ul className={styles.citationsList}>
                    {msg.citations.map((cite, idx) => (
                      <li key={idx}>
                        <a
                          href={cite.url}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          {cite.chapter}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        ))}

        {isLoading && (
          <div className={styles.loadingContainer}>
            <div className={styles.loadingBubble}>
              <div className={styles.loadingDot}></div>
              <div className={styles.loadingDot}></div>
              <div className={styles.loadingDot}></div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className={styles.inputContainer}>
        <div className={styles.inputWrapper}>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
              }
            }}
            placeholder="Ask a question..."
            className={styles.messageInput}
            rows={1}
            disabled={isLoading}
          />
          <button
            onClick={() => sendMessage()}
            disabled={isLoading || !input.trim()}
            className={styles.sendButton}
            title="Send message (Enter)"
          >
            {isLoading ? '⏳' : '➤'}
          </button>
        </div>
        <p className={styles.inputHint}>
          Press Enter to send
        </p>
      </div>
    </div>
  );
}
