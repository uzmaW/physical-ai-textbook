/**
 * PersonalizedChapter Component
 * Wraps chapter content with personalization and translation features
 */

import React, { useState, useEffect } from 'react';
import { useUserStore } from '@site/src/store/userStore';

interface PersonalizedChapterProps {
  id: string;
  children: React.ReactNode;
}

export function PersonalizedChapter({ id, children }: PersonalizedChapterProps): JSX.Element {
  const { userProfile, updatePreferences } = useUserStore();

  const [difficulty, setDifficulty] = useState(
    userProfile?.preferences?.difficulty_preference || 'intermediate'
  );
  const [isUrdu, setIsUrdu] = useState(false);
  const [urduContent, setUrduContent] = useState<string | null>(null);
  const [isTranslating, setIsTranslating] = useState(false);

  // Cycle through difficulty levels
  const handlePersonalize = () => {
    const levels: Array<'beginner' | 'intermediate' | 'advanced'> = ['beginner', 'intermediate', 'advanced'];
    const currentIndex = levels.indexOf(difficulty);
    const nextLevel = levels[(currentIndex + 1) % 3];

    setDifficulty(nextLevel);
    updatePreferences({ difficulty_preference: nextLevel });
  };

  // Toggle Urdu translation
  const handleTranslate = async () => {
    if (isUrdu) {
      setIsUrdu(false);
      return;
    }

    setIsTranslating(true);

    try {
      const userId = userProfile?.id || 'guest';

      // Check cache first
      const cacheResponse = await fetch(
        `http://localhost:8000/api/translate/cached?userId=${userId}&chapterId=${id}`
      );

      if (cacheResponse.ok) {
        const cached = await cacheResponse.json();
        setUrduContent(cached.content);
        setIsUrdu(true);
      } else {
        // Translate and cache
        const translateResponse = await fetch('http://localhost:8000/api/translate/', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId,
            chapterId: id,
            content: extractTextContent(children),
            targetLang: 'ur'
          })
        });

        if (translateResponse.ok) {
          const result = await translateResponse.json();
          setUrduContent(result.translatedContent);
          setIsUrdu(true);
        } else {
          console.error('Translation failed');
        }
      }
    } catch (error) {
      console.error('Translation error:', error);
      alert('Translation service unavailable. Please try again later.');
    } finally {
      setIsTranslating(false);
    }
  };

  // Extract text content from React children
  const extractTextContent = (node: React.ReactNode): string => {
    if (typeof node === 'string') return node;
    if (typeof node === 'number') return node.toString();
    if (Array.isArray(node)) return node.map(extractTextContent).join(' ');
    if (React.isValidElement(node) && node.props.children) {
      return extractTextContent(node.props.children);
    }
    return '';
  };

  return (
    <div className="personalized-chapter">
      {/* Chapter Header with Controls */}
      <div className="chapter-header flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg mb-6 shadow-sm">
        <div className="flex items-center gap-3">
          <span
            className={`difficulty-badge px-3 py-1 rounded-full text-sm font-medium ${
              difficulty === 'beginner'
                ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                : difficulty === 'intermediate'
                ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
                : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
            }`}
          >
            {difficulty.charAt(0).toUpperCase() + difficulty.slice(1)} Mode
          </span>
        </div>

        <div className="flex gap-3">
          <button
            onClick={handlePersonalize}
            className="personalize-btn px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium shadow-sm hover:shadow-md"
            title="Cycle through difficulty levels: Beginner → Intermediate → Advanced"
          >
            🎯 Personalize Content
          </button>

          <button
            onClick={handleTranslate}
            className="translate-btn px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium shadow-sm hover:shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={isTranslating}
            title={isUrdu ? 'Switch back to English' : 'Translate to Urdu'}
            style={{ fontFamily: isUrdu ? 'inherit' : 'Noto Nastaliq Urdu, serif' }}
          >
            {isTranslating ? '⏳ Translating...' : isUrdu ? 'English' : 'ترجمہ کریں'}
          </button>
        </div>
      </div>

      {/* Chapter Content */}
      <div
        className={`chapter-content ${isUrdu ? 'urdu-text' : ''}`}
        data-difficulty={difficulty}
      >
        {isUrdu && urduContent ? (
          <div
            className="prose dark:prose-invert max-w-none urdu-content"
            style={{
              fontFamily: 'Noto Nastaliq Urdu, serif',
              fontSize: '1.25em',
              lineHeight: '2',
              direction: 'rtl',
              textAlign: 'right'
            }}
            dangerouslySetInnerHTML={{ __html: urduContent }}
          />
        ) : (
          <div className="prose dark:prose-invert max-w-none">
            {children}
          </div>
        )}
      </div>
    </div>
  );
}
